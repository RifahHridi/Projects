const reviews =[
    {
       
        name:"john",
        job: "architect", 
        img:"img4.jpg"

    },

    {
        
        name:"Pink",
        job: "Front end dev",
        img:"img1.jpg"
    },

    {
        
        name:"Dale",
        job: "UI/UX",
        img:"download.jfif"
    },
];

const name=document.getElementById("name");
const job=document.getElementById("job");
let img= document.getElementById("img");

let prevbtn=document.getElementById("prev-btn");
let nextbtn=document.getElementById("next-btn");


let currentItem=0;

window.addEventListener('DOMContentLoaded',function(){
    console.log('test');
    showPerson(currentItem);

});
function showPerson(person){
    const item= reviews[currentItem];
    img.src= item.img;
    name.textContent=item.name;
    job.textContent=item.job;

}

nextbtn.addEventListener("click",function(){
    currentItem++;
    if(currentItem>reviews.length-1){
currentItem=0;
    }
    showPerson(currentItem);
})
prevbtn.addEventListener("click",function(){
    currentItem--;
    if(currentItem<0){
        currentItem=reviews.length-1;
            }
    showPerson(currentItem);
})