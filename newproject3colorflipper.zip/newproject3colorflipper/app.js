  

document.getElementById("myBtn").addEventListener("click",a );
function a () {

  let rC = randomColor();
     document.body.style.background = rC.bgColor;
     document.getElementById('myBtn').style.backgroundColor = rC.btncolor;
  
 }

function randomColor(){
  var x = Math.floor(Math.random() * 256);
  var y = Math.floor(Math.random() * 256);
  var z = Math.floor(Math.random() * 256);

  return {
    bgColor :"rgb(" + x + "," + y + "," + z + ")",
    btncolor : "rgb(" + y + "," + x + "," + z + ")"
  }
   
}