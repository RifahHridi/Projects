<!DOCTYPE html>
<html>
<head>
<title>X Titan E-Comm </title>
<style>
h1 {
  border: 1px solid red;
  margin-top: 50px;
  margin-right: 300px;
  margin-left: 300px;
  padding-top:50px;
  padding-left:100px;
  padding-bottom:50px;
  background-color: lightblue;
}
h3 {
  border: 1px solid red;
  margin-top: 50px;
  margin-bottom:100px;
  margin-right: 300px;
  margin-left: 300px;
  padding-top:50px;
  padding-left:100px;
  padding-bottom:50px;
  background-color: lightblue;
}

form {
  border: 1px solid red;
  margin-top: 100px;
  margin-bottom: 300px;
  margin-right: 300px;
  margin-left: 300px;
  padding-top:50px;
  padding-left:100px;
  padding-bottom:50px;
  background-color: lightblue;
}
</style>
<h3>X Titan E-Comm Announcement Board Configuration</h3>
</head>
<body>
<form name="Announcement_Settings " method="post" action="admin_rules.php">
  Select drinks type <select name="drinks"  >
    <option value="Cocacola">Cocacola</option>
    <option value="Fanta">Fanta</option>
    <option value="Pepsi">Pepsi</option>
    <option value="100 Plus">100 Plus</option>
  </select>
  <br>
Select promotion days <select name="promotion_days_drinks" >
    <option value="7 Days">1 week</option>
    <option value="14 Days">2 Week</option>
    <option value="21 Days">3 Week</option>
    <option value="28 Days">4 Week</option>
  </select>
  <br>
   Select Promotion Discount (in %)  <input name="promotion_discount_drinks" type="number">  
  <br><br>
  
  Select oil brand <select name="oil" >
    <option value="Canola">Canola</option>
    <option value="Sunflower">Sunflower</option>
  </select>
  <br>
Select promotion days <select name="promotion_days_oil">
    <option value="7 Days">1 week</option>
    <option value="14 Days">2 Week</option>
    <option value="21 Days">3 Week</option>
    <option value="28 Days">4 Week</option>
  </select>
  <br>
   Select Promotion Discount (in %)  <input name="promotion_discount_oil" type="number">  
  <br><br>

   Select lotion type <select name="lotion" >
    <option value="Nivea">Nivea</option>
    <option value="Ponds">Ponds</option>
    <option value="Johonson">Johonson</option>
    <option value="Clear">Clear</option>
  </select>
  <br>
  Select promotion days <select name="promotion_days_lotion">
    <option value="7 Days">1 week</option>
    <option value="14 Days">2 Week</option>
    <option value="21 Days">3 Week</option>
    <option value="28 Days">4 Week</option>
  </select>
  <br>
   Select Promotion Discount (in %)  <input name="promotion_discount_lotion" type="number">  
  <br><br>

   Select MegaPrize type <select name="MegaPrize" >
    <option value="MegaPrizes">MegaPrize</option>
    </select>
  <br>
  Select promotion days <select name="promotion_days_Megaprize">
    <option value="7 Days">1 week</option>
    <option value="14 Days">2 Week</option>
    <option value="21 Days">3 Week</option>
    <option value="28 Days">4 Week</option>
  </select>
  <br>
   Promotion Megaprize Detail  <input name="promotion_Megaprize_detail" type="text">  
  <br>
  <br>
  <input type="submit">
  <br>
  <br>
  <br>
  <?php include_once ('footer.php'); ?>
  </form>
</body>

</html>