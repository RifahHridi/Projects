<!DOCTYPE html>
<html>
<?php
echo "Copy right belongs to Sharker Mohammad Abu Syeed ID_110057230 and Rifaf Mashiat 110056911, X Titan E-Comm" ;
?>

</html>