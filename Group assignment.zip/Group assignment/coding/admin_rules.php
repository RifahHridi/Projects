<!DOCTYPE html>
<html>
<head> 
<title>X Titan E-Comm </title> 
<style>
h3,h5 {
  border: 1px solid red;
  margin-top: 50px;
  margin-right: 300px;
  margin-left: 300px;
  padding-top:50px;
  padding-left:100px;
  padding-bottom:50px;
  background-color: lightblue;
}
</style>
</head>
<body>
<h3>
X Titan E-Comm Announcement Board 
</h3>
<h5>
Changes has been successfully saved
</h5>
<?php
$data = $_POST['drinks'].PHP_EOL.$_POST['promotion_days_drinks'].PHP_EOL.$_POST['promotion_discount_drinks'].PHP_EOL.
$_POST['oil'].PHP_EOL.$_POST['promotion_days_oil'].PHP_EOL.$_POST['promotion_discount_oil'].PHP_EOL.
$_POST['lotion'].PHP_EOL.$_POST['promotion_days_lotion'].PHP_EOL.$_POST['promotion_discount_lotion'].PHP_EOL.
$_POST['MegaPrize'].PHP_EOL.$_POST['promotion_days_Megaprize'].PHP_EOL.$_POST['promotion_Megaprize_detail'];

$file = fopen("announcement_data.txt","w");
fwrite($file,$data);
fclose($file);
?>
</body>
<?php include_once ('footer.php'); ?>
</html>