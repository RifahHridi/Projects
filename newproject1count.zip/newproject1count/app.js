'use strict';
let count=0;

const valuei=document.querySelector('.value');
const btns= document.querySelectorAll('.btn');
console.log(btns);

btns.forEach(function(btni){
btni.addEventListener('click', function(e){
const btnchange=e.currentTarget.classList;
if(btnchange.contains("decrease")){
    count--;
} valuei.textContent=count;
if(btnchange.contains("increase")){
count++;
}valuei.textContent=count;
if(btnchange.contains("Reset")){
    count=0;
    }valuei.textContent=count;
});
});