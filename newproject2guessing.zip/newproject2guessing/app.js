let scoreguess = parseInt(document.querySelector('.score').textContent = "0");

// let scoreguess= document.querySelector('.score').textContent;
// scoreguess=0;


document.querySelector('.check').addEventListener('click',function(e){
    e.preventDefault();

    const guess=Number(document.querySelector('.guess').value);
    // console.log(guess, typeof guess);
    const num=Math.floor(Math.random()*20)+1;

    const numbrguess=document.querySelector('.numbr').textContent=num;

    
    if(numbrguess===guess){
        document.querySelector('.message').textContent="Correct Number";
       
        scoreguess++;
        document.querySelector('.score').textContent = scoreguess;
    }
    if(numbrguess!==guess){
        scoreguess--;
        document.querySelector('.score').textContent = scoreguess;
        document.querySelector('.message').textContent="Wrong Number";
    }
    if(!guess){

        document.querySelector('.message').textContent='No number';
    }

})










